rootProject.name = "NaverShoppingSearch_Project"

